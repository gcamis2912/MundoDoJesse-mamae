package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.ELOGIOS
import com.familia.mundodojesse.data.FRASES_APOIO_ERRO
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.ConfettiOverlay
import com.familia.mundodojesse.ui.components.FundoComEstrelas
import com.familia.mundodojesse.ui.components.IconeCartoon
import com.familia.mundodojesse.ui.components.TipoIcone
import com.familia.mundodojesse.ui.theme.*
import kotlin.random.Random

private val FORMAS_JOGO = listOf(TipoIcone.ESTRELA, TipoIcone.BOLA, TipoIcone.CASA, TipoIcone.PRESENTE, TipoIcone.BALAO_FALA)

@Composable
fun SombraScreen(nome: String, tts: TtsManager, repo: ProgressoRepository, aoVoltar: () -> Unit) {
    var formaAlvo by remember { mutableStateOf(FORMAS_JOGO.random()) }
    var opcoes by remember { mutableStateOf(gerarOpcoes(formaAlvo)) }
    var mostrarConfete by remember { mutableStateOf(false) }
    var dica by remember { mutableStateOf<TipoIcone?>(null) }

    fun novaRodada() {
        formaAlvo = FORMAS_JOGO.random()
        opcoes = gerarOpcoes(formaAlvo)
        dica = null
    }

    LaunchedEffect(Unit) {
        tts.falar("Vamos encontrar a sombra que combina, $nome? Olha essa forma aqui!")
    }

    FundoComEstrelas(gradiente = GradienteGrape) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.height(10.dp))
            Text("Qual sombra combina?", fontSize = 22.sp, color = Color.White)
            Spacer(Modifier.height(20.dp))

            Box(
                Modifier
                    .size(120.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                IconeCartoon(formaAlvo, tamanho = 80.dp, corPrincipal = Sun)
            }

            Spacer(Modifier.height(36.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                opcoes.forEach { forma ->
                    Box(
                        Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(if (dica == forma) Color(0xFFFFE29A) else Color(0x33FFFFFF))
                            .clickable {
                                if (forma == formaAlvo) {
                                    repo.somarEstrela("sombra")
                                    mostrarConfete = true
                                    tts.falar("${ELOGIOS[Random.nextInt(ELOGIOS.size)]} Encontrou a sombra certinha, $nome!")
                                    novaRodada()
                                } else {
                                    tts.falar(FRASES_APOIO_ERRO[Random.nextInt(FRASES_APOIO_ERRO.size)])
                                    dica = formaAlvo
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        IconeCartoon(forma, tamanho = 60.dp, corPrincipal = Color(0xFF2B2740))
                    }
                }
            }
        }
        ConfettiOverlay(visivel = mostrarConfete)
        LaunchedEffect(mostrarConfete) {
            if (mostrarConfete) {
                kotlinx.coroutines.delay(1200)
                mostrarConfete = false
            }
        }
    }
}

private fun gerarOpcoes(certa: TipoIcone): List<TipoIcone> {
    val restantes = FORMAS_JOGO.filter { it != certa }.shuffled().take(2)
    return (restantes + certa).shuffled()
}
