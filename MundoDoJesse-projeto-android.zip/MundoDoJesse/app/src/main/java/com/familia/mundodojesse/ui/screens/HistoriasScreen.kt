package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.HISTORIAS
import com.familia.mundodojesse.data.comNome
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.FundoComEstrelas
import com.familia.mundodojesse.ui.theme.*

@Composable
fun HistoriasScreen(nome: String, aoAbrirHistoria: (String) -> Unit, aoVoltar: () -> Unit) {
    FundoComEstrelas(gradiente = GradienteCoral) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.height(10.dp))
            Text("Historinhas 📖", fontSize = 24.sp, color = Color.White)
            Spacer(Modifier.height(16.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(HISTORIAS) { historia ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White)
                            .clickable { aoAbrirHistoria(historia.id) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(CircleShape).background(Cream),
                            contentAlignment = Alignment.Center
                        ) { Text(historia.emoji, fontSize = 26.sp) }
                        Spacer(Modifier.width(14.dp))
                        Text(historia.titulo.comNome(nome), fontSize = 17.sp, color = Ink)
                    }
                }
            }
        }
    }
}
