package com.familia.mundodojesse.data

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun String.comNome(nome: String) = this.replace("{nome}", nome)

/**
 * Guarda tudo que precisa "lembrar" entre uma abertura e outra do app: nome da criança,
 * quantas estrelinhas ela já ganhou em cada atividade, e quanto tempo usou por dia
 * (pra mostrar na Área dos Pais). Tudo fica salvo no próprio aparelho, sem internet.
 */
class ProgressoRepository(context: Context) {
    private val prefs = context.getSharedPreferences("mundo_do_jesse_prefs", Context.MODE_PRIVATE)
    private val formatoDia = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getNome(): String = prefs.getString("nome_crianca", NOME_PADRAO) ?: NOME_PADRAO
    fun salvarNome(nome: String) { prefs.edit().putString("nome_crianca", nome.ifBlank { NOME_PADRAO }).apply() }

    fun getEstrelas(categoria: String): Int = prefs.getInt("estrelas_$categoria", 0)
    fun somarEstrela(categoria: String) {
        prefs.edit().putInt("estrelas_$categoria", getEstrelas(categoria) + 1).apply()
    }

    // Tempo de uso: soma minutos no dia de hoje, guarda um histórico simples dos últimos dias
    fun registrarMinutoDeUso() {
        val chaveHoje = "minutos_" + formatoDia.format(Date())
        val atual = prefs.getInt(chaveHoje, 0)
        prefs.edit().putInt(chaveHoje, atual + 1).apply()
        // mantém lista de dias com uso, pra Área dos Pais conseguir listar o histórico
        val dias = prefs.getStringSet("dias_com_uso", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        dias.add(formatoDia.format(Date()))
        prefs.edit().putStringSet("dias_com_uso", dias).apply()
    }

    fun getMinutosHoje(): Int = prefs.getInt("minutos_" + formatoDia.format(Date()), 0)

    fun getHistoricoUltimosDias(qtdDias: Int = 7): List<Pair<String, Int>> {
        val cal = java.util.Calendar.getInstance()
        val lista = mutableListOf<Pair<String, Int>>()
        repeat(qtdDias) {
            val chaveData = formatoDia.format(cal.time)
            val minutos = prefs.getInt("minutos_$chaveData", 0)
            lista.add(chaveData to minutos)
            cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        return lista.reversed()
    }

    fun getTotalEstrelas(): Int {
        val categorias = listOf("historias", "letras", "sombra", "futebol", "frases", "contagem")
        return categorias.sumOf { getEstrelas(it) }
    }
}
