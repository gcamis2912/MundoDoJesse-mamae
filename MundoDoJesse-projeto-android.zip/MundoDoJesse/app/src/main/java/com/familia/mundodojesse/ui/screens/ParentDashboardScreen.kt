package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.ui.theme.*

@Composable
fun ParentDashboardScreen(repo: ProgressoRepository, aoVoltar: () -> Unit) {
    var nomeEditavel by remember { mutableStateOf(repo.getNome()) }
    val historico = remember { repo.getHistoricoUltimosDias(7) }
    val totalEstrelas = remember { repo.getTotalEstrelas() }
    val minutosHoje = remember { repo.getMinutosHoje() }

    Column(Modifier.fillMaxSize().background(Cream).padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⬅️", fontSize = 22.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.width(12.dp))
            Text("Área dos Pais", fontSize = 24.sp, color = Ink)
        }
        Spacer(Modifier.height(20.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                CartaoPais(titulo = "Nome da criança") {
                    BasicTextField(
                        value = nomeEditavel,
                        onValueChange = {
                            nomeEditavel = it
                            repo.salvarNome(it)
                        },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, color = Ink),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    )
                }
            }
            item {
                CartaoPais(titulo = "Tempo de uso hoje") {
                    Text("$minutosHoje minuto(s)", fontSize = 22.sp, color = Grape)
                }
            }
            item {
                CartaoPais(titulo = "Estrelinhas conquistadas no total") {
                    Text("⭐ $totalEstrelas estrelinhas", fontSize = 22.sp, color = SunDeep)
                }
            }
            item {
                CartaoPais(titulo = "Últimos 7 dias") {
                    Column {
                        historico.forEach { (dia, minutos) ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(dia, fontSize = 14.sp, color = Ink)
                                Text("$minutos min", fontSize = 14.sp, color = Grape)
                            }
                        }
                    }
                }
            }
            item {
                CartaoPais(titulo = "Sobre o app") {
                    Text(
                        "Este app funciona 100% offline. Nenhum dado é enviado pra internet — tudo fica guardado só neste aparelho.",
                        fontSize = 13.sp, color = Ink
                    )
                }
            }
        }
    }
}

@Composable
private fun CartaoPais(titulo: String, conteudo: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(18.dp))
            .padding(18.dp)
    ) {
        Text(titulo, fontSize = 15.sp, color = Grape)
        Spacer(Modifier.height(8.dp))
        conteudo()
    }
}
