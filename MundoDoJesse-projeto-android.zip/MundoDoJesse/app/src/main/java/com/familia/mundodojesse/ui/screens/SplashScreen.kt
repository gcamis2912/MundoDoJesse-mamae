package com.familia.mundodojesse.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.AFIRMACOES
import com.familia.mundodojesse.data.SAUDACOES
import com.familia.mundodojesse.tts.TtsManager
import kotlin.random.Random

@Composable
fun SplashScreen(nome: String, tts: TtsManager, aoComecar: () -> Unit) {
    val pulso = rememberInfiniteTransition(label = "pulso")
    val escala by pulso.animateFloat(
        initialValue = 1f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "escalaPulso"
    )

    LaunchedEffect(Unit) {
        val saudacao = SAUDACOES[Random.nextInt(SAUDACOES.size)](nome)
        // De vez em quando, além do "oi", o app reforça pro Jessé o quanto ele é amado — devagar, com os anos, sem cansar.
        if (Random.nextInt(3) == 0) {
            val afirmacao = AFIRMACOES[Random.nextInt(AFIRMACOES.size)](nome)
            tts.falar("$saudacao $afirmacao")
        } else {
            tts.falar(saudacao)
        }
    }

    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🌟", fontSize = 90.sp)
        Spacer(Modifier.height(12.dp))
        Text("Mundo do $nome", fontSize = 32.sp, color = Color.White)
        Spacer(Modifier.height(30.dp))
        Text(
            "Vamos brincar! ✨",
            fontSize = 24.sp,
            color = Color.White,
            modifier = Modifier
                .graphicsLayer { scaleX = escala; scaleY = escala }
                .background(Color(0x33FFFFFF), RoundedCornerShape(30.dp))
                .clickable(onClick = aoComecar)
                .padding(horizontal = 32.dp, vertical = 16.dp)
        )
    }
}
