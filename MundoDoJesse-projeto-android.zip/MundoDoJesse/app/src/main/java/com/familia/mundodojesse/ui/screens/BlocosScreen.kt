package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.ELOGIOS
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.ConfettiOverlay
import com.familia.mundodojesse.ui.components.FundoComEstrelas
import com.familia.mundodojesse.ui.theme.*
import kotlin.random.Random

private val CORES_BLOCOS = listOf(Coral, Sun, Leaf, Sky, Grape, Pink)

@Composable
fun BlocosScreen(nome: String, tts: TtsManager, repo: ProgressoRepository, aoVoltar: () -> Unit) {
    var pilha by remember { mutableStateOf(listOf<Color>()) }
    var mostrarConfete by remember { mutableStateOf(false) }
    val meta = 5

    LaunchedEffect(Unit) {
        tts.falar("Vamos empilhar blocos coloridos, $nome? Toca aqui embaixo pra colocar mais um!")
    }

    FundoComEstrelas(gradiente = GradienteSky) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.height(6.dp))
            Text("Blocos de Cor — ${pilha.size}/$meta", fontSize = 22.sp, color = Color.White)

            Spacer(Modifier.weight(1f))
            Column(
                modifier = Modifier.align(Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                pilha.reversed().forEach { cor ->
                    Box(
                        Modifier
                            .size(width = 90.dp, height = 40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(cor)
                    )
                }
            }
            Spacer(Modifier.height(24.dp))

            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .clickable {
                        val novaCor = CORES_BLOCOS.random()
                        pilha = pilha + novaCor
                        tts.falar("${pilha.size}! ${ELOGIOS[Random.nextInt(ELOGIOS.size)]}")
                        if (pilha.size >= meta) {
                            repo.somarEstrela("contagem")
                            mostrarConfete = true
                            tts.falar("Uau, $nome, você empilhou todos os blocos! Que demais!")
                            pilha = emptyList()
                        }
                    }
                    .padding(horizontal = 30.dp, vertical = 16.dp)
            ) {
                Text("➕ Colocar bloco", fontSize = 18.sp, color = Ink)
            }
            Spacer(Modifier.height(30.dp))
        }
        ConfettiOverlay(visivel = mostrarConfete)
        LaunchedEffect(mostrarConfete) {
            if (mostrarConfete) {
                kotlinx.coroutines.delay(1500)
                mostrarConfete = false
            }
        }
    }
}
