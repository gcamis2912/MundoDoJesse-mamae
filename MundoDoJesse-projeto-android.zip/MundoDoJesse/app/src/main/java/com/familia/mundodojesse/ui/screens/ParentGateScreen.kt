package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.ui.theme.*
import kotlin.random.Random

/**
 * Barreira simples pra impedir que a criança entre sozinha na Área dos Pais:
 * uma continha de matemática que só um adulto resolve rapidinho.
 */
@Composable
fun ParentGateScreen(aoLiberar: () -> Unit, aoVoltar: () -> Unit) {
    var numeroA by remember { mutableStateOf(Random.nextInt(2, 8)) }
    var numeroB by remember { mutableStateOf(Random.nextInt(2, 8)) }
    var mensagemErro by remember { mutableStateOf(false) }

    val respostaCerta = numeroA + numeroB
    val opcoes = remember(numeroA, numeroB) {
        val erradas = mutableSetOf<Int>()
        while (erradas.size < 2) {
            val candidata = respostaCerta + Random.nextInt(-4, 5)
            if (candidata != respostaCerta && candidata > 0) erradas.add(candidata)
        }
        (erradas + respostaCerta).shuffled()
    }

    Column(
        Modifier.fillMaxSize().background(Grape).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Área dos Pais 👨‍👩‍👧", fontSize = 26.sp, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Text("Pra continuar, resolva a continha:", fontSize = 16.sp, color = Color.White)
        Spacer(Modifier.height(20.dp))
        Text("$numeroA + $numeroB = ?", fontSize = 40.sp, color = Color.White)
        Spacer(Modifier.height(28.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            opcoes.forEach { opcao ->
                Text(
                    "$opcao",
                    fontSize = 24.sp,
                    color = Ink,
                    modifier = Modifier
                        .background(Color.White, RoundedCornerShape(18.dp))
                        .clickable {
                            if (opcao == respostaCerta) {
                                aoLiberar()
                            } else {
                                mensagemErro = true
                                numeroA = Random.nextInt(2, 8)
                                numeroB = Random.nextInt(2, 8)
                            }
                        }
                        .padding(horizontal = 26.dp, vertical = 16.dp)
                )
            }
        }

        if (mensagemErro) {
            Spacer(Modifier.height(18.dp))
            Text("Ops, não foi essa. Tenta a nova continha!", color = Color.White, fontSize = 14.sp)
        }

        Spacer(Modifier.height(40.dp))
        Text("⬅️ Voltar", color = Color.White, fontSize = 14.sp, modifier = Modifier.clickable { aoVoltar() })
    }
}
