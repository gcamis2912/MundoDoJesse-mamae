package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.ui.components.*
import com.familia.mundodojesse.ui.theme.*

data class ItemMenu(val titulo: String, val icone: TipoIcone, val gradiente: Brush, val corIcone: Color, val rota: String)

val ITENS_MENU = listOf(
    ItemMenu("Histórias", TipoIcone.LIVRO, GradienteCoral, Coral, "historias"),
    ItemMenu("Sombras", TipoIcone.SOMBRA, GradienteGrape, Grape, "sombra"),
    ItemMenu("Futebol", TipoIcone.BOLA, GradienteLeaf, Leaf, "futebol"),
    ItemMenu("Blocos de Cor", TipoIcone.BLOCOS, GradienteSky, Sky, "blocos"),
    ItemMenu("Fala e Sons", TipoIcone.BALAO_FALA, GradientePink, Pink, "fonoterapia"),
    ItemMenu("Minhas Letrinhas", TipoIcone.LETRA, GradienteSun, SunDeep, "alfabetizacao"),
    ItemMenu("Frases Gentis", TipoIcone.CASA, GradientePink, Pink, "frases"),
    ItemMenu("Presente da Família", TipoIcone.PRESENTE, GradienteSun, SunDeep, "presente")
)

@Composable
fun HomeScreen(nome: String, aoNavegar: (String) -> Unit, aoAbrirAreaPais: () -> Unit) {
    FundoComEstrelas(gradiente = GradienteFundoPrincipal) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconeCartoon(TipoIcone.ESTRELA, tamanho = 34.dp, corPrincipal = Sun)
                    Spacer(Modifier.width(8.dp))
                    Text("Mundo do $nome", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                // ícone discreto da Área dos Pais, no canto — não chama atenção da criança
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                        .clickable(onClick = aoAbrirAreaPais),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⚙", fontSize = 16.sp, color = Color.White)
                }
            }
            Spacer(Modifier.height(22.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(ITENS_MENU) { item ->
                    CartaoAtividade(
                        titulo = item.titulo,
                        icone = item.icone,
                        gradiente = item.gradiente,
                        corIcone = item.corIcone,
                        modifier = Modifier.fillMaxWidth()
                    ) { aoNavegar(item.rota) }
                }
            }
        }
    }
}
