package com.familia.mundodojesse.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.ELOGIOS
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.ConfettiOverlay
import com.familia.mundodojesse.ui.components.IconeCartoon
import com.familia.mundodojesse.ui.components.TipoIcone
import com.familia.mundodojesse.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun FutebolScreen(nome: String, tts: TtsManager, repo: ProgressoRepository, aoVoltar: () -> Unit) {
    val escopo = rememberCoroutineScope()
    val posicaoBolaY = remember { Animatable(0f) }
    var gols by remember { mutableStateOf(repo.getEstrelas("futebol")) }
    var mostrarConfete by remember { mutableStateOf(false) }
    var chutando by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        tts.falar("Vamos jogar futebol, $nome? Toca na bolinha pra chutar pro gol!")
    }

    fun chutar() {
        if (chutando) return
        chutando = true
        escopo.launch {
            posicaoBolaY.animateTo(-520f, animationSpec = tween(550))
            gols++
            repo.somarEstrela("futebol")
            mostrarConfete = true
            val elogio = ELOGIOS[Random.nextInt(ELOGIOS.size)]
            tts.falar("Golaaaço! $elogio Você é o craque, $nome!")
            posicaoBolaY.snapTo(0f)
            kotlinx.coroutines.delay(1400)
            mostrarConfete = false
            chutando = false
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(GradienteLeaf)
            .clickable { chutar() }
    ) {
        // gol (trave), desenhado simples no topo
        Canvas(modifier = Modifier.fillMaxWidth().height(140.dp).align(Alignment.TopCenter)) {
            val margem = size.width * 0.22f
            drawRect(
                color = Color.White,
                topLeft = Offset(margem, 0f),
                size = androidx.compose.ui.geometry.Size(size.width - margem * 2, size.height),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 10f)
            )
        }

        Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(20.dp).clickable { aoVoltar() })

        Text(
            "⚽ Gols: $gols",
            fontSize = 20.sp,
            color = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(20.dp)
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 60.dp)
                .offset(y = posicaoBolaY.value.dp)
        ) {
            IconeCartoon(TipoIcone.BOLA, tamanho = 90.dp, corPrincipal = Color.White)
        }

        Text(
            "Toca na tela pra chutar! 👆",
            fontSize = 16.sp,
            color = Color.White,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
        )

        ConfettiOverlay(visivel = mostrarConfete)
    }
}
