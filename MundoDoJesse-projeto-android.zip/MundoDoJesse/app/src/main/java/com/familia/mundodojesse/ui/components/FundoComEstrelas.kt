package com.familia.mundodojesse.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

private data class Estrelinha(val x: Float, val y: Float, val raio: Float, val fase: Float)

/**
 * Fundo colorido em degradê, com estrelinhas piscando suavemente ao fundo —
 * usado atrás de todas as telas principais do app pra dar um clima mágico.
 */
@Composable
fun FundoComEstrelas(gradiente: Brush, modifier: Modifier = Modifier, conteudo: @Composable () -> Unit) {
    val estrelinhas = remember {
        List(22) {
            Estrelinha(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                raio = Random.nextFloat() * 3f + 2f,
                fase = Random.nextFloat() * 6.28f
            )
        }
    }
    val transicao = rememberInfiniteTransition(label = "brilho")
    val tempo by transicao.animateFloat(
        initialValue = 0f, targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "tempoBrilho"
    )

    androidx.compose.foundation.layout.Box(modifier = modifier.fillMaxSize().background(gradiente)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            estrelinhas.forEach { estrela ->
                val brilho = (kotlin.math.sin(tempo + estrela.fase) + 1f) / 2f
                drawCircle(
                    color = Color.White.copy(alpha = 0.25f + brilho * 0.5f),
                    radius = estrela.raio,
                    center = Offset(estrela.x * size.width, estrela.y * size.height)
                )
            }
        }
        conteudo()
    }
}
