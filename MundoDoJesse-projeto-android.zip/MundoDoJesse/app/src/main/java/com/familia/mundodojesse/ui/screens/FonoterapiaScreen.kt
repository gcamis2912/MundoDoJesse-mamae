package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.FundoComEstrelas
import com.familia.mundodojesse.ui.theme.*

data class SomImitar(val nome: String, val emoji: String, val onomatopeia: String)

private val SONS_FONOTERAPIA = listOf(
    SomImitar("Cachorro", "🐶", "Au au!"),
    SomImitar("Gato", "🐱", "Miau!"),
    SomImitar("Vaca", "🐄", "Muuu!"),
    SomImitar("Carro", "🚗", "Vrum vrum!"),
    SomImitar("Trem", "🚂", "Tuc tuc tuc!"),
    SomImitar("Chuva", "🌧️", "Pling plong!"),
    SomImitar("Passarinho", "🐦", "Piu piu!"),
    SomImitar("Boi", "🐮", "Mooo!"),
    SomImitar("Beijo", "😘", "Mwah!"),
    SomImitar("Coração", "❤️", "Tum tum!")
)

@Composable
fun FonoterapiaScreen(nome: String, tts: TtsManager, repo: ProgressoRepository, aoVoltar: () -> Unit) {
    androidx.compose.runtime.LaunchedEffect(Unit) {
        tts.falar("Vamos brincar com os sons, $nome? Toca e depois tenta repetir comigo!")
    }
    FundoComEstrelas(gradiente = GradientePink) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.height(10.dp))
            Text("Fala e Sons 🗣️", fontSize = 24.sp, color = Color.White)
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(SONS_FONOTERAPIA) { som ->
                    Column(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color.White)
                            .clickable {
                                tts.falar("${som.nome} faz assim: ${som.onomatopeia} Agora tenta você, $nome!")
                                repo.somarEstrela("frases")
                            }
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(som.emoji, fontSize = 40.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(som.nome, fontSize = 16.sp, color = Ink)
                        Text(som.onomatopeia, fontSize = 14.sp, color = Grape)
                    }
                }
            }
        }
    }
}
