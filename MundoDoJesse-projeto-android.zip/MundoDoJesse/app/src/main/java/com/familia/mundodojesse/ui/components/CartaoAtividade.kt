package com.familia.mundodojesse.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Cartão grande de atividade, com visual "premium": gradiente colorido, sombra 3D projetada,
 * badge branco com o ícone cartoon dentro, e uma mola suave que reage ao toque do dedinho.
 */
@Composable
fun CartaoAtividade(
    titulo: String,
    icone: TipoIcone,
    gradiente: Brush,
    corIcone: Color,
    modifier: Modifier = Modifier,
    aoClicar: () -> Unit
) {
    val interacao = remember { MutableInteractionSource() }
    val pressionado by interacao.collectIsPressedAsState()
    val escala by animateFloatAsState(
        targetValue = if (pressionado) 0.90f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "escalaCartao"
    )
    val elevacao by animateDpAsState(
        targetValue = if (pressionado) 2.dp else 10.dp, label = "elevacaoCartao"
    )

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = escala; scaleY = escala }
            .shadow(elevation = elevacao, shape = RoundedCornerShape(32.dp), clip = false)
            .clip(RoundedCornerShape(32.dp))
            .background(gradiente)
            .clickable(interactionSource = interacao, indication = null, onClick = aoClicar)
            .padding(vertical = 18.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .shadow(4.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            IconeCartoon(tipo = icone, tamanho = 40.dp, corPrincipal = corIcone)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            titulo,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 19.sp
        )
    }
}
