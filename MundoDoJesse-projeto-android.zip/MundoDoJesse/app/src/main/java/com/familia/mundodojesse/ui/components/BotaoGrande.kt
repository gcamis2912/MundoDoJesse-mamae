package com.familia.mundodojesse.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Botão grande, colorido, com "bounce" suave ao tocar — pensado pra dedinho de criança pequena,
 * então a área de toque é generosa e o feedback visual é bem claro.
 */
@Composable
fun BotaoGrande(
    texto: String,
    emoji: String,
    cor: Color,
    modifier: Modifier = Modifier,
    aoClicar: () -> Unit
) {
    val interacao = remember { MutableInteractionSource() }
    val pressionado by interacao.collectIsPressedAsState()
    val escala by animateFloatAsState(
        targetValue = if (pressionado) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.5f), label = "escalaBotao"
    )

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = escala; scaleY = escala }
            .clip(RoundedCornerShape(28.dp))
            .background(cor)
            .clickable(interactionSource = interacao, indication = null, onClick = aoClicar)
            .padding(vertical = 22.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 46.sp)
        Spacer(Modifier.height(6.dp))
        Text(texto, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
