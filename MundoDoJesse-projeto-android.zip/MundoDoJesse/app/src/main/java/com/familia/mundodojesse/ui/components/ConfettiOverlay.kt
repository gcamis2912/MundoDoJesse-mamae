package com.familia.mundodojesse.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.min
import kotlin.random.Random

private data class Confetinho(
    val xInicial: Float, val corIndex: Int, val atraso: Int, val rotacaoBase: Float
)

private val CoresConfete = listOf(
    Color(0xFFFF6F61), Color(0xFFFFC93C), Color(0xFF4CAF7D),
    Color(0xFF6EC6FF), Color(0xFF8B5FBF), Color(0xFFFF9EC7)
)

/**
 * Chuvinha de confete colorido — usada toda vez que a criança acerta algo.
 * `visivel` controla quando aparece; o efeito se autolimpa sozinho.
 */
@Composable
fun ConfettiOverlay(visivel: Boolean) {
    if (!visivel) return
    val particulas = remember {
        List(45) {
            Confetinho(
                xInicial = Random.nextFloat(),
                corIndex = Random.nextInt(CoresConfete.size),
                atraso = Random.nextInt(400),
                rotacaoBase = Random.nextFloat() * 360f
            )
        }
    }
    val progresso = remember { Animatable(0f) }
    LaunchedEffect(visivel) {
        progresso.snapTo(0f)
        progresso.animateTo(1f, animationSpec = tween(1800, easing = LinearEasing))
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val alturaTotal = size.height
        val larguraTotal = size.width
        particulas.forEach { p ->
            val t = (progresso.value * 1800 - p.atraso).coerceIn(0f, 1800f) / 1800f
            if (t <= 0f) return@forEach
            val y = t * (alturaTotal + 60f) - 30f
            val x = p.xInicial * larguraTotal
            rotate(p.rotacaoBase + t * 360f, pivot = androidx.compose.ui.geometry.Offset(x, y)) {
                drawRect(
                    color = CoresConfete[p.corIndex].copy(alpha = min(1f, 1.3f - t)),
                    topLeft = androidx.compose.ui.geometry.Offset(x, y),
                    size = androidx.compose.ui.geometry.Size(14f, 14f)
                )
            }
        }
    }
}
