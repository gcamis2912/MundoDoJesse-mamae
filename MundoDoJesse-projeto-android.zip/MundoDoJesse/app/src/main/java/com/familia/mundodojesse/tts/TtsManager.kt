package com.familia.mundodojesse.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Fala em português com o app inteiro.
 *
 * IMPORTANTE — leia isto: o Android não tem como usar uma "voz humana de mamãe" de verdade
 * sem gravar áudios reais (que este projeto não inclui). O que este gerenciador faz é pegar
 * a voz de português já instalada no aparelho (geralmente do Google) e ajustar o tom (mais agudo)
 * e a velocidade (mais devagar) pra soar o mais suave e acolhedor possível dentro do que existe.
 * Se quiser depois trocar por áudios gravados de verdade, dá pra substituir o método `falar`
 * por um MediaPlayer tocando arquivos .mp3 gravados pela família — fica MUITO mais carinhoso.
 */
class TtsManager(context: Context) {
    private var tts: TextToSpeech? = null
    private var pronto = false
    private val filaPendente = mutableListOf<String>()

    var aoComecarFala: (() -> Unit)? = null
    var aoTerminarFala: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                tts?.setPitch(1.28f)       // mais agudo, som mais suave/infantil
                tts?.setSpeechRate(0.86f)  // mais devagar, pra criança pequena acompanhar
                escolherVozMaisSuave()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { aoComecarFala?.invoke() }
                    override fun onDone(utteranceId: String?) { aoTerminarFala?.invoke() }
                    @Deprecated("compat") override fun onError(utteranceId: String?) {}
                })
                pronto = true
                filaPendente.forEach { falarAgora(it) }
                filaPendente.clear()
            }
        }
    }

    // Tenta achar, entre as vozes instaladas, uma que soe mais suave (nem toda marca de tablet tem opções)
    private fun escolherVozMaisSuave() {
        try {
            val vozes = tts?.voices ?: return
            val candidata = vozes.firstOrNull {
                it.locale.language == "pt" && (it.name.contains("female", true) || it.name.contains("#female", true))
            }
            candidata?.let { tts?.voice = it }
        } catch (_: Exception) { /* alguns aparelhos não suportam listar vozes — sem problema, usa a padrão */ }
    }

    fun falar(texto: String) {
        if (!pronto) { filaPendente.add(texto); return }
        falarAgora(texto)
    }

    private fun falarAgora(texto: String) {
        tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, texto.hashCode().toString())
    }

    fun liberar() {
        tts?.stop()
        tts?.shutdown()
    }
}
