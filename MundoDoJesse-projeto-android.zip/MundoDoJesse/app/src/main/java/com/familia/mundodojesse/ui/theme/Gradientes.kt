package com.familia.mundodojesse.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val GradienteFundoPrincipal = Brush.verticalGradient(
    colors = listOf(Grape, GrapeDeep)
)

val GradienteCoral = Brush.linearGradient(colors = listOf(Coral, Color(0xFFE85A4E)))
val GradienteLeaf = Brush.linearGradient(colors = listOf(Leaf, Color(0xFF3A9A68)))
val GradienteSky = Brush.linearGradient(colors = listOf(Sky, Color(0xFF4FA8E8)))
val GradientePink = Brush.linearGradient(colors = listOf(Pink, Color(0xFFE874AC)))
val GradienteSun = Brush.linearGradient(colors = listOf(Sun, SunDeep))
val GradienteGrape = Brush.linearGradient(colors = listOf(Grape, GrapeDeep))
