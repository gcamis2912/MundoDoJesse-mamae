package com.familia.mundodojesse.data

// ================= NOME DA CRIANÇA =================
// Trocável na Área dos Pais (fica salvo em SharedPreferences via ProgressoRepository)
const val NOME_PADRAO = "Jessé"

// ================= SAUDAÇÕES (variam a cada vez que ele abre o app) =================
val SAUDACOES: List<(String) -> String> = listOf(
    { nome -> "Oi, $nome! Que alegria te ver! O que vamos fazer hoje?" },
    { nome -> "Olá, meu amor, $nome! Vamos brincar juntinhos?" },
    { nome -> "$nome, que bom te ver de novo! Estava com saudade!" },
    { nome -> "Oiii, $nome! Pronto pra um dia cheio de descobertas?" },
    { nome -> "Seja bem-vindo, $nome! Vamos aprender brincando?" }
)

// ================= ELOGIOS (proibido usar "arrasou") =================
val ELOGIOS = listOf(
    "Isso, meu amor!", "Muito bem!", "Você é muito inteligente!", "Parabéns!",
    "Que lindo!", "Ebaaa, conseguiu!", "Show de bola!", "Uau, que demais!",
    "Você consegue tudo!", "Isso mesmo, viu só!"
)

// Usado no sistema de apoio ao erro — NUNCA existe bronca no app, só incentivo
val FRASES_APOIO_ERRO = listOf(
    "Quase lá, meu amor! Tenta assim...",
    "Você está indo bem! Vamos tentar de novo, juntinhos?",
    "Isso, continua tentando, você consegue!",
    "Calma, sem pressa nenhuma — vamos de novo?"
)

// ================= LETRAS DO NOME "JESSÉ" =================
data class LetraNome(val letra: Char, val corHex: Long)
val LETRAS_JESSE = listOf(
    LetraNome('J', 0xFFFF6F61),
    LetraNome('E', 0xFFFFC93C),
    LetraNome('S', 0xFF4CAF7D),
    LetraNome('S', 0xFF6EC6FF),
    LetraNome('É', 0xFF8B5FBF)
)

// ================= FRASES GENTIS (boas maneiras) =================
data class FraseGentil(val frase: String, val emoji: String, val quando: String)
val FRASES_GENTIS = listOf(
    FraseGentil("Bom dia", "☀️", "Fala \"bom dia\" quando acorda. E vê alguém de manhã."),
    FraseGentil("Boa tarde", "🌤️", "Fala \"boa tarde\" quando vê alguém de tardinha."),
    FraseGentil("Boa noite", "🌙", "Fala \"boa noite\" na hora de dormir."),
    FraseGentil("Oi", "👋", "Fala \"oi\" quando encontra alguém."),
    FraseGentil("Tchau", "👋", "Fala \"tchau\" quando vai embora, dando tchauzinho com a mão."),
    FraseGentil("Por favor", "🙏", "Fala \"por favor\" quando quer pedir uma coisinha."),
    FraseGentil("Obrigado", "🙏", "Fala \"obrigado\" quando ganha algo, ou alguém te ajuda."),
    FraseGentil("Não, obrigado", "🙅", "Fala \"não, obrigado\" quando não quer uma coisa. Sempre com educação."),
    FraseGentil("De nada", "😊", "Fala \"de nada\" quando alguém te agradece."),
    FraseGentil("Com licença", "🚪", "Fala \"com licença\" quando quer passar."),
    FraseGentil("Desculpa", "😊", "Fala \"desculpa\" quando machuca alguém sem querer. Ou quando solta um arrotinho ou um puzinho."),
    FraseGentil("Tudo bem, acontece", "😌", "Fala isso quando alguém te pede desculpa. Pra deixar a pessoa tranquila."),
    FraseGentil("Não tem problema", "🤗", "Fala isso pra dizer que está tudo bem, sem ficar bravo.")
)

// ================= AFIRMAÇÕES (quem ele é, repetido com carinho) =================
val AFIRMACOES: List<(String) -> String> = listOf(
    { nome -> "$nome, você é muito especial." },
    { nome -> "$nome, você é valioso, viu?" },
    { nome -> "$nome, você é uma criança educada e gentil." },
    { nome -> "Deus ama você demais, $nome." },
    { nome -> "A mamãe ama você mais que tudo nesse mundo, $nome." },
    { nome -> "$nome, você é amado, sempre." }
)

// ================= HISTÓRIAS BÍBLICAS (linguagem de 2 aninhos) =================
data class SlideHistoria(val emoji: String, val texto: String)
data class Historia(val id: String, val titulo: String, val emoji: String, val slides: List<SlideHistoria>)

val HISTORIAS = listOf(
    Historia(
        id = "amor_jesus",
        titulo = "Jesus Te Ama, {nome}!",
        emoji = "💛",
        slides = listOf(
            SlideHistoria("✨", "Jesus olha pra {nome} todo dia, com um sorriso grande, cheio de amor."),
            SlideHistoria("🤗", "Jesus cuida de {nome} de pertinho, como um abraço quentinho o dia inteiro."),
            SlideHistoria("🌙", "De noite, enquanto {nome} dorme, Jesus fica de olho, protegendo bem baixinho."),
            SlideHistoria("💛", "Jesus ama {nome} pra sempre, não importa o que aconteça. Pra sempre mesmo!")
        )
    ),
    Historia(
        id = "noe",
        titulo = "Noé e o Barquinho",
        emoji = "🚢",
        slides = listOf(
            SlideHistoria("👴", "Deus pediu pro Noé fazer um barco bem grandão."),
            SlideHistoria("🐘", "Os bichinhos entraram dois a dois: au au, muu, miau!"),
            SlideHistoria("🌧️", "Choveu bastante, mas todo mundo ficou seguro e quentinho."),
            SlideHistoria("🌈", "Depois, apareceu um arco-íris lindo, colorido no céu!")
        )
    ),
    Historia(
        id = "davi",
        titulo = "Davi, o Menino Corajoso",
        emoji = "🐑",
        slides = listOf(
            SlideHistoria("🐑", "Davi era pequenininho, mas tinha um coração corajoso."),
            SlideHistoria("😨", "Apareceu um gigante grandão. Todo mundo ficou com medo."),
            SlideHistoria("🎯", "Davi confiou em Deus e foi corajoso, bem cheio de fé."),
            SlideHistoria("🎉", "Todo mundo comemorou! Deus estava cuidando de Davi.")
        )
    ),
    Historia(
        id = "presente",
        titulo = "O Maior Presente da Mamãe",
        emoji = "💝",
        slides = listOf(
            SlideHistoria("🤰", "Antes de {nome} nascer, a mamãe já amava ele demais."),
            SlideHistoria("👶", "Quando {nome} nasceu, a vida da mamãe ficou cheia de luz e alegria."),
            SlideHistoria("💝", "{nome} é o maior presente que a mamãe já ganhou na vida."),
            SlideHistoria("🥰", "Toda vez que {nome} sorri, a mamãe fica muito mais feliz. Ela te ama, {nome}!")
        )
    ),
    Historia(
        id = "carta_mamae",
        titulo = "Uma Cartinha da Mamãe pra {nome}",
        emoji = "💌",
        slides = listOf(
            SlideHistoria("💌", "{nome}, a mamãe fez esse aplicativo inteirinho com muito, muito amor, só pra você."),
            SlideHistoria("🌟", "Você é especial, {nome}. Você é valioso. Você é uma criança educada e cheia de luz."),
            SlideHistoria("🙏", "Deus ama você demais, {nome}. E a mamãe ama você mais que tudo nesse mundo."),
            SlideHistoria("💛", "Não importa o tamanho que você fique, {nome}, a mamãe vai estar sempre aqui, te amando. Sempre.")
        )
    )
)
