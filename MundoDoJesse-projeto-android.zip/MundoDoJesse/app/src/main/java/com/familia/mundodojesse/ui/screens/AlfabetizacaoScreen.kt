package com.familia.mundodojesse.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.ELOGIOS
import com.familia.mundodojesse.data.FRASES_APOIO_ERRO
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.ConfettiOverlay
import com.familia.mundodojesse.ui.components.FundoComEstrelas
import com.familia.mundodojesse.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * NOTA HONESTA SOBRE ESTA TELA: aqui o app não faz um reconhecimento "pixel perfeito" do
 * traçado (isso exigiria testes num aparelho real pra calibrar direito). O que ele faz é
 * contar quantas áreas diferentes da letra a criança já tocou com o dedo — assim que ela
 * cobre uma boa parte, o app comemora. Nunca existe mensagem de erro: se cobrir pouco, o
 * app só espera e depois de alguns segundos dá uma dica carinhosa, sem pressa nenhuma.
 */
@Composable
fun AlfabetizacaoScreen(nome: String, tts: TtsManager, repo: ProgressoRepository, aoVoltar: () -> Unit) {
    val letras = remember(nome) { nome.uppercase().toList().filter { it.isLetter() } }
    var indiceLetra by remember { mutableStateOf(0) }
    val letraAtual = letras.getOrElse(indiceLetra) { letras.first() }

    val pontosDesenhados = remember(indiceLetra) { mutableStateListOf<Offset>() }
    val caminho = remember(indiceLetra) { Path() }
    var mostrarConfete by remember { mutableStateOf(false) }
    var mostrarDica by remember { mutableStateOf(false) }
    var tamanhoCanvas by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }

    LaunchedEffect(indiceLetra) {
        mostrarDica = false
        tts.falar("Vamos traçar a letra $letraAtual, $nome? Passa o dedinho por cima dela.")
        delay(7000)
        if (pontosDesenhados.size < 12) {
            mostrarDica = true
            tts.falar(FRASES_APOIO_ERRO[Random.nextInt(FRASES_APOIO_ERRO.size)])
        }
    }

    fun verificarCobertura() {
        if (tamanhoCanvas == androidx.compose.ui.geometry.Size.Zero || pontosDesenhados.isEmpty()) return
        val colunas = 8
        val linhas = 8
        val celulasTocadas = mutableSetOf<Pair<Int, Int>>()
        pontosDesenhados.forEach { p ->
            val cx = (p.x / tamanhoCanvas.width * colunas).toInt().coerceIn(0, colunas - 1)
            val cy = (p.y / tamanhoCanvas.height * linhas).toInt().coerceIn(0, linhas - 1)
            celulasTocadas.add(cx to cy)
        }
        val fracao = celulasTocadas.size.toFloat() / (colunas * linhas)
        if (fracao >= 0.22f) {
            repo.somarEstrela("letras")
            mostrarConfete = true
            tts.falar("${ELOGIOS[Random.nextInt(ELOGIOS.size)]} Você escreveu o $letraAtual, $nome!")
        }
    }

    FundoComEstrelas(gradiente = GradienteSun) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.height(6.dp))
            Text("Minhas Letrinhas — $nome", fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color.White)
                    .pointerInput(indiceLetra) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                caminho.moveTo(offset.x, offset.y)
                                pontosDesenhados.add(offset)
                            },
                            onDrag = { change, _ ->
                                caminho.lineTo(change.position.x, change.position.y)
                                pontosDesenhados.add(change.position)
                            },
                            onDragEnd = { verificarCobertura() }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize().onSizeChangedCompat { tamanhoCanvas = it }) {
                    // letra-guia, bem clarinha, atrás do traço
                    drawContext.canvas.nativeCanvas.apply {
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.parseColor("#E6DEF5")
                            textSize = size.height * 0.68f
                            textAlign = android.graphics.Paint.Align.CENTER
                            isAntiAlias = true
                        }
                        drawText(
                            letraAtual.toString(),
                            size.width / 2,
                            size.height / 2 + size.height * 0.24f,
                            paint
                        )
                    }
                    drawPath(
                        caminho,
                        color = Sky,
                        style = Stroke(width = 26f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
                if (mostrarDica) {
                    Text(
                        "👉 Tenta assim, devagarinho!",
                        fontSize = 16.sp,
                        color = Grape,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "🧹 Limpar",
                    color = Color.White,
                    fontSize = 15.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x33FFFFFF))
                        .clickable { pontosDesenhados.clear(); caminho.reset() }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )
                Text(
                    "Letra ${indiceLetra + 1} de ${letras.size}",
                    color = Color.White,
                    fontSize = 15.sp
                )
            }
        }
        ConfettiOverlay(visivel = mostrarConfete)
        LaunchedEffect(mostrarConfete) {
            if (mostrarConfete) {
                delay(1600)
                mostrarConfete = false
                indiceLetra = (indiceLetra + 1) % letras.size
            }
        }
    }
}

// pequeno auxiliar pra pegar o tamanho do Canvas assim que ele é desenhado
private fun Modifier.onSizeChangedCompat(aoMudar: (androidx.compose.ui.geometry.Size) -> Unit): Modifier =
    this.then(
        androidx.compose.ui.layout.onGloballyPositioned { coords ->
            aoMudar(androidx.compose.ui.geometry.Size(coords.size.width.toFloat(), coords.size.height.toFloat()))
        }
    )
