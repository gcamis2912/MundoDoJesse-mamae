package com.familia.mundodojesse.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta pensada pra ser vibrante, alegre e bem visível pra uma criança de 2 anos
val Grape = Color(0xFF8B5FBF)
val GrapeDeep = Color(0xFF6A3FA0)
val Coral = Color(0xFFFF6F61)
val Sun = Color(0xFFFFC93C)
val SunDeep = Color(0xFFF0A800)
val Leaf = Color(0xFF4CAF7D)
val Sky = Color(0xFF6EC6FF)
val Pink = Color(0xFFFF9EC7)
val Ink = Color(0xFF3B3450)
val Paper = Color(0xFFFDFBF6)
val Cream = Color(0xFFFFF6E9)
