package com.familia.mundodojesse.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * Ícones "cartoon" desenhados com formas geométricas simples (círculos, curvas, linhas),
 * no lugar de usar emoji de texto — fica com aparência mais de aplicativo profissional
 * e ilustrado, sem depender de nenhuma imagem externa (o app continua 100% offline).
 */

enum class TipoIcone { LIVRO, SOMBRA, BOLA, BLOCOS, BALAO_FALA, PRESENTE, ESTRELA, CASA, LETRA }

@Composable
fun IconeCartoon(tipo: TipoIcone, tamanho: androidx.compose.ui.unit.Dp = 56.dp, corPrincipal: Color = Color.White) {
    Canvas(modifier = Modifier.size(tamanho)) {
        val w = size.width
        val h = size.height
        when (tipo) {
            TipoIcone.LIVRO -> desenharLivro(w, h, corPrincipal)
            TipoIcone.SOMBRA -> desenharSombra(w, h, corPrincipal)
            TipoIcone.BOLA -> desenharBola(w, h, corPrincipal)
            TipoIcone.BLOCOS -> desenharBlocos(w, h, corPrincipal)
            TipoIcone.BALAO_FALA -> desenharBalaoFala(w, h, corPrincipal)
            TipoIcone.PRESENTE -> desenharPresente(w, h, corPrincipal)
            TipoIcone.ESTRELA -> desenharEstrela(w, h, corPrincipal)
            TipoIcone.CASA -> desenharCasa(w, h, corPrincipal)
            TipoIcone.LETRA -> desenharLetraAbc(w, h, corPrincipal)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharLivro(w: Float, h: Float, cor: Color) {
    val margem = w * 0.12f
    drawRoundRect(
        color = cor,
        topLeft = Offset(margem, h * 0.18f),
        size = androidx.compose.ui.geometry.Size(w - margem * 2, h * 0.64f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.08f)
    )
    drawLine(
        color = Color(0x33000000),
        start = Offset(w / 2, h * 0.18f),
        end = Offset(w / 2, h * 0.82f),
        strokeWidth = w * 0.025f
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharSombra(w: Float, h: Float, cor: Color) {
    val pontos = listOf(
        Offset(w * 0.5f, h * 0.1f), Offset(w * 0.62f, h * 0.38f), Offset(w * 0.92f, h * 0.4f),
        Offset(w * 0.68f, h * 0.6f), Offset(w * 0.78f, h * 0.9f), Offset(w * 0.5f, h * 0.72f),
        Offset(w * 0.22f, h * 0.9f), Offset(w * 0.32f, h * 0.6f), Offset(w * 0.08f, h * 0.4f),
        Offset(w * 0.38f, h * 0.38f)
    )
    val caminho = androidx.compose.ui.graphics.Path().apply {
        moveTo(pontos[0].x, pontos[0].y)
        pontos.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawPath(caminho, color = cor)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharBola(w: Float, h: Float, cor: Color) {
    val raio = w * 0.42f
    val centro = Offset(w / 2, h / 2)
    drawCircle(color = cor, radius = raio, center = centro)
    drawCircle(color = Color(0x33000000), radius = raio, center = centro, style = Stroke(width = w * 0.03f))
    // pentágono no meio, clássico visual de bola
    val ptsPentagono = (0 until 5).map { i ->
        val angulo = Math.toRadians((-90 + i * 72).toDouble())
        Offset(
            centro.x + (raio * 0.42f) * cos(angulo).toFloat(),
            centro.y + (raio * 0.42f) * sin(angulo).toFloat()
        )
    }
    val caminho = androidx.compose.ui.graphics.Path().apply {
        moveTo(ptsPentagono[0].x, ptsPentagono[0].y)
        ptsPentagono.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawPath(caminho, color = Color(0xFF3B3450))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharBlocos(w: Float, h: Float, cor: Color) {
    val tamanhoBloco = w * 0.36f
    drawRoundRect(
        color = cor,
        topLeft = Offset(w * 0.08f, h * 0.5f),
        size = androidx.compose.ui.geometry.Size(tamanhoBloco, tamanhoBloco),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.06f)
    )
    drawRoundRect(
        color = Color(0xE6FFFFFF),
        topLeft = Offset(w * 0.5f, h * 0.5f),
        size = androidx.compose.ui.geometry.Size(tamanhoBloco, tamanhoBloco),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.06f)
    )
    drawRoundRect(
        color = cor.copy(alpha = 0.75f),
        topLeft = Offset(w * 0.29f, h * 0.14f),
        size = androidx.compose.ui.geometry.Size(tamanhoBloco, tamanhoBloco),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.06f)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharBalaoFala(w: Float, h: Float, cor: Color) {
    drawRoundRect(
        color = cor,
        topLeft = Offset(w * 0.1f, h * 0.12f),
        size = androidx.compose.ui.geometry.Size(w * 0.8f, h * 0.56f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.18f)
    )
    val caminho = androidx.compose.ui.graphics.Path().apply {
        moveTo(w * 0.28f, h * 0.62f)
        lineTo(w * 0.2f, h * 0.86f)
        lineTo(w * 0.46f, h * 0.64f)
        close()
    }
    drawPath(caminho, color = cor)
    listOf(0.34f, 0.5f, 0.66f).forEach { fx ->
        drawCircle(color = Color(0xFFFFFFFF), radius = w * 0.045f, center = Offset(w * fx, h * 0.4f))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharPresente(w: Float, h: Float, cor: Color) {
    drawRoundRect(
        color = cor,
        topLeft = Offset(w * 0.16f, h * 0.4f),
        size = androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.48f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.06f)
    )
    drawRect(
        color = Color(0xFFFFFFFF),
        topLeft = Offset(w * 0.16f, h * 0.28f),
        size = androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.14f)
    )
    drawRect(
        color = Color(0xFFFFFFFF),
        topLeft = Offset(w * 0.46f, h * 0.28f),
        size = androidx.compose.ui.geometry.Size(w * 0.08f, h * 0.6f)
    )
    // laço
    drawCircle(color = cor.copy(alpha = 0.85f), radius = w * 0.12f, center = Offset(w * 0.38f, h * 0.24f))
    drawCircle(color = cor.copy(alpha = 0.85f), radius = w * 0.12f, center = Offset(w * 0.62f, h * 0.24f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharEstrela(w: Float, h: Float, cor: Color) {
    val centro = Offset(w / 2, h / 2)
    val raioFora = w * 0.46f
    val raioDentro = w * 0.2f
    val pontos = (0 until 10).map { i ->
        val raio = if (i % 2 == 0) raioFora else raioDentro
        val angulo = Math.toRadians((-90 + i * 36).toDouble())
        Offset(centro.x + raio * cos(angulo).toFloat(), centro.y + raio * sin(angulo).toFloat())
    }
    val caminho = androidx.compose.ui.graphics.Path().apply {
        moveTo(pontos[0].x, pontos[0].y)
        pontos.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }
    drawPath(caminho, color = cor)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharCasa(w: Float, h: Float, cor: Color) {
    val telhado = androidx.compose.ui.graphics.Path().apply {
        moveTo(w * 0.5f, h * 0.12f)
        lineTo(w * 0.12f, h * 0.46f)
        lineTo(w * 0.88f, h * 0.46f)
        close()
    }
    drawPath(telhado, color = cor)
    drawRect(
        color = cor,
        topLeft = Offset(w * 0.2f, h * 0.46f),
        size = androidx.compose.ui.geometry.Size(w * 0.6f, h * 0.42f)
    )
    drawRect(
        color = Color(0xFFFFFFFF),
        topLeft = Offset(w * 0.42f, h * 0.62f),
        size = androidx.compose.ui.geometry.Size(w * 0.16f, h * 0.26f)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.desenharLetraAbc(w: Float, h: Float, cor: Color) {
    drawLine(cor, Offset(w * 0.2f, h * 0.85f), Offset(w * 0.2f, h * 0.15f), strokeWidth = w * 0.14f, cap = StrokeCap.Round)
    drawLine(cor, Offset(w * 0.2f, h * 0.15f), Offset(w * 0.75f, h * 0.15f), strokeWidth = w * 0.14f, cap = StrokeCap.Round)
    drawLine(cor, Offset(w * 0.2f, h * 0.5f), Offset(w * 0.62f, h * 0.5f), strokeWidth = w * 0.13f, cap = StrokeCap.Round)
    drawLine(cor, Offset(w * 0.2f, h * 0.85f), Offset(w * 0.75f, h * 0.85f), strokeWidth = w * 0.14f, cap = StrokeCap.Round)
}
