package com.familia.mundodojesse.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val CoresApp = lightColorScheme(
    primary = Grape,
    secondary = Coral,
    tertiary = Sun,
    background = Paper,
    surface = Paper,
    onPrimary = Paper,
    onBackground = Ink,
    onSurface = Ink
)

private val TipografiaApp = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp, color = Ink),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Ink),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 20.sp, color = Ink),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink)
)

@Composable
fun MundoDoJesseTheme(content: @Composable () -> Unit) {
    // O app sempre usa o tema claro e colorido — não faz sentido "modo escuro" pra criança de 2 anos
    MaterialTheme(
        colorScheme = CoresApp,
        typography = TipografiaApp,
        content = content
    )
}
