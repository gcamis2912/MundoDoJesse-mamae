package com.familia.mundodojesse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familia.mundodojesse.data.HISTORIAS
import com.familia.mundodojesse.data.ProgressoRepository
import com.familia.mundodojesse.data.comNome
import com.familia.mundodojesse.tts.TtsManager
import com.familia.mundodojesse.ui.components.ConfettiOverlay
import com.familia.mundodojesse.ui.components.FundoComEstrelas
import com.familia.mundodojesse.ui.theme.*

@Composable
fun HistoriaDetalheScreen(historiaId: String, nome: String, tts: TtsManager, repo: ProgressoRepository, aoVoltar: () -> Unit) {
    val historia = remember { HISTORIAS.first { it.id == historiaId } }
    var indice by remember { mutableStateOf(0) }
    var mostrarConfete by remember { mutableStateOf(false) }
    val slide = historia.slides[indice]
    val ultimo = indice == historia.slides.size - 1

    LaunchedEffect(indice) {
        tts.falar(slide.texto.comNome(nome))
    }

    FundoComEstrelas(gradiente = GradienteCoral) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("⬅️", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { aoVoltar() })
            Spacer(Modifier.height(6.dp))
            Text(historia.titulo.comNome(nome), fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color.White)
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(slide.emoji, fontSize = 70.sp)
                Spacer(Modifier.height(16.dp))
                Text(slide.texto.comNome(nome), fontSize = 19.sp, color = Ink, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }

            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "⬅️ Antes",
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (indice > 0) Color(0x33FFFFFF) else Color.Transparent)
                        .clickable(enabled = indice > 0) { indice-- }
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                )
                Text(
                    if (ultimo) "Terminar 🎉" else "Depois ➡️",
                    color = Color.White,
                    fontSize = 16.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x55FFFFFF))
                        .clickable {
                            if (ultimo) {
                                repo.somarEstrela("historias")
                                mostrarConfete = true
                                tts.falar("Que história linda, $nome! Deus te ama muito!")
                            } else indice++
                        }
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                )
            }
        }
        ConfettiOverlay(visivel = mostrarConfete)
        LaunchedEffect(mostrarConfete) {
            if (mostrarConfete) {
                kotlinx.coroutines.delay(1800)
                mostrarConfete = false
                aoVoltar()
            }
        }
    }
}
