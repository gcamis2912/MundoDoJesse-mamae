// Arquivo de configuração do projeto inteiro (não mexer, a não ser que saiba o que está fazendo)
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
